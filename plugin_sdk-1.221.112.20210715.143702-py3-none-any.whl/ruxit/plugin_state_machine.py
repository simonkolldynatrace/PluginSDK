import collections, copy, importlib, io, logging, sys, threading, time, traceback, datetime
from enum import IntEnum
from contextlib import contextmanager
from typing import List, NamedTuple

import ruxit.api.data, ruxit.api.exceptions, ruxit.api.selectors, ruxit.config_utils
import ruxit.utils._logging.engine_logging
from ruxit.api.base_plugin import ExternalFunctions
from ruxit.package_utils.class_factory import generate_state_enum, generate_state_metric
from ruxit.api.results_builder import ResultsBuilder
from ruxit.api.selectors import EntityType
from ruxit.plugin_status_reporter import PluginFullStatus, PluginState
from ruxit.tools.limit_checker import LimitChecker, MultiLimitChecker
from ruxit.utils.execute_every_minute import is_interval_passed
from ruxit.api.events import EventMetadataKey
from ruxit.messages import EXECUTION_TIMEOUT

ExecStat = collections.namedtuple('ExecStat', ['start_time', 'end_time', 'thread_id', 'cpu_info'])
StateData = collections.namedtuple('StateData',['states'])

WrappedPluginMeasurementList = collections.namedtuple('WrappedPluginMeasurementList', ['timestamp', 'measurements'])
WrappedEventList = collections.namedtuple('WrappedEventList', ['events'])
WrappedPluginMeasurement = collections.namedtuple(
    'WrappedPluginMeasurement',
    ['monitoredEntityId', 'tsIdentifier', 'dimensions', 'value', 'aggregation', 'isV3', 'isStatetimeseries', 'isStatCounter']
)
Dimension = collections.namedtuple('Dimension', ['key', 'value'])

CustomPropertyProtoWrapper = collections.namedtuple(
    'CustomPropertyProtoWrapper',
    ['key', 'value', 'me_attribute']
)

WrappedEvent = collections.namedtuple('WrappedEvent', ['type', 'identifier', 'entity_id', 'me_type', 'event_metadata'])
WrappedEventMetadata = collections.namedtuple('WrappedEventMetadata', ['key', 'value', 'is_boolean', 'is_float', 'is_int',
                                                                       'is_custom_properties'])

WrappedResults = collections.namedtuple("WrappedResults", ["measurements", "properties", "events"])


class PluginStateGroups:
    errors = {PluginState.ERROR_UNKNOWN, PluginState.ERROR_CONFIG, PluginState.ERROR_AUTH}
    recoverable_errors = {PluginState.ERROR_CONFIG, PluginState.ERROR_AUTH}
    mostly_fine = {PluginState.OK, PluginState.NOTHING_TO_REPORT, PluginState.LIMIT_REACHED}

    @staticmethod
    def is_error(state):
        return state in PluginStateGroups.errors

    @staticmethod
    def is_recoverable_error(state):
        return state in PluginStateGroups.recoverable_errors

    @staticmethod
    def is_fine(state):
        return state in PluginStateGroups.mostly_fine


class AggregationTypes(IntEnum):
    avg = 1,
    sum = 4


PluginRunData = collections.namedtuple('PluginRunData',
                                       ["plugin_class", "plugin_name", "plugin_args",
                                        "plugin_instance"])


class PluginEngine(object):
    # documented in lifecycle guide
    measure_interval_seconds = 60

    _exc_to_state = {
        ruxit.api.exceptions.ConfigException: PluginState.ERROR_CONFIG,
        ruxit.api.exceptions.AuthException: PluginState.ERROR_AUTH,
    }

    # documented in lifecycle guide
    _crash_limit = 20

    def __init__(self, *, external_api, entity_resolver, plugin_info, activation_context):
        self.plugin_info = plugin_info
        self.metadata = plugin_info.json_data
        self.config = None
        self.external_api = external_api
        self.entity_resolver = entity_resolver
        self.activation_context = activation_context

        self.logger = logging.getLogger("plugin_development." + plugin_info.reported_name) if plugin_info.is_in_development else logging.getLogger(__name__)

        self._crash_count = 0
        self._executions_count = 0
        self.execution_timeout = False
        self._stats = collections.deque(maxlen=10)

        self.results_builder = ResultsBuilder(self.logger, self.external_api, plugin_info.topx_data)

        self._selector_cache = {}
        self.last_wrapped_results = None

        self.set_full_status(PluginState.UNINITIALIZED)

        self._last_timestamp = None
        # documented in lifecycle guide
        self.config_reset_interval_seconds = 3600
        self.fast_check_id = None
        self.fast_status_ready = None

        #add custom and state metrics metadata
        self.metadata_by_metric = {}
        self.states_data = {}
        for m in self.metadata.get("metrics", []):
            metric_data = m.get("timeseries", None)
            if not metric_data:
                metric_data = m.get("statetimeseries", None)
                if not metric_data:
                    continue
                metric_key = metric_data["key"]
                self.states_data [metric_key] = PluginEngine._get_state_info(metric_data)
                generate_state_enum(plugin_info.package, metric_key, metric_data["states"])
                generate_state_metric(plugin_info.package, metric_key)
            self.metadata_by_metric[metric_data["key"]] = m

        self._start_time = self.local_timestamp
        self._measure_size = LimitChecker(lambda: self.results_builder.PLUGIN_MEASUREMENTS_LIMIT)
        self._event_count = LimitChecker(lambda: self.results_builder.PLUGIN_EVENTS_LIMIT)
        self._properties_limit = MultiLimitChecker (lambda: self.results_builder.PLUGIN_PROPERTY_LIMIT)
        self._group_properties_limit = MultiLimitChecker(lambda: self.results_builder.PLUGIN_GROUP_PROPERTY_LIMIT)
        self._plugin_run_data = None
        self.__limits_exceeded = []

    @property
    def is_fast_check(self) -> bool:
        return True if self.fast_check_id is not None else False

    @staticmethod
    def _get_state_info(metadata):
        states = {}
        count = 0
        for state in metadata["states"]:
            states [state] = count
            count += 1
        return StateData(states)

    def get_snapshot(self):
        return self.entity_resolver.get_snapshot()

    def get_logger(self):
        return self.logger

    
    #cluster timestamp in seconds 
    @property
    def local_timestamp(self)->float:
        return self.external_api.get_timestamp()/1000.0


    #cluster timestamp in seconds
    @property
    def cluster_timestamp(self)->float:
        return self.external_api.get_cluster_timestamp()/1000.0


    #Lists of messages describing limits exceeded in current query
    @property
    def limits_exceeded(self)->List[str]:
        return self.__limits_exceeded

    #add information about reached limit
    def add_limit_exceeded(self, value:str):
        self.__limits_exceeded.append(value)


    #check if it's sharp minute to run next query
    @property
    def __is_interval_passed(self)->bool:
        if self.measure_interval_seconds == 60:
            #default mode: start sharp at every minute
            time_now = datetime.datetime.fromtimestamp(self.cluster_timestamp)
            return self._last_timestamp is None \
                or self._last_timestamp.minute != time_now.minute
        else:
            #simulator mode: interval is customizable
            return is_interval_passed (self._start_time,
                                       self.measure_interval_seconds,
                                       self._last_timestamp.timestamp(),
                                       self.local_timestamp)
        
        
    def ready_for_set_config(self, new_config, fast_check_id):
        #new config or fast check always run a plugin
        if new_config is None:
            return False
        if fast_check_id:
            return True
        if new_config != self.config:
            return True
        #otherwise plugin is run if interval (1 minute) is passed
        if not self.__is_interval_passed:
            return False
        if PluginStateGroups.is_error(self.state) and not self._crash_limit_exceeded():
            return True
        return PluginStateGroups.is_recoverable_error(self.state)
    

    def ready_for_measure(self):
        return PluginStateGroups.is_fine(self._state) \
               and (self.fast_check_id or self.__is_interval_passed)

    def get_name(self):
        return self.metadata["name"]

    def get_id(self):
        return (
            self.metadata['name'],
            self.get_entity_id()
        )

    def is_initialized(self):
        return self.state != PluginState.UNINITIALIZED

    @property
    def state(self)->PluginState:
        return self._state 
        
    def set_full_status(self, state:PluginState, exception_info=None, description:str = None ):
        self._state = state
        if description is None and exception_info is not None:
            description = self._get_exception_message(exception_info)

        if description is not None and \
                len(description) > 0 and \
                self.config is not None:
            #remove user sensitive information
            sensitive_values = [property[1] for property in self.config.items() \
                                if property[0] in self.config.to_mask]
            for v in sensitive_values:
                if len(v) > 1:
                    description = description.replace(v, '******')

        self.full_status = PluginFullStatus(
            pluginName=self.plugin_info.reported_name,
            pluginVersion=self.metadata['version'],
            state=state.value,
            description= description or "",
            stacktrace=self._get_exception_stacktrace(exception_info) if exception_info else "",
            monitoredEntityId=self.get_entity_id()
        )

    def get_full_status(self):
        return self.full_status

    def _get_exception_message(self, exception_info):
        try:
            if len(exception_info[1].args) > 0:
                return str(exception_info[1].args[0])
            else:
                return ""
        except:
            self.logger.info("Exception on extracting plugin error message", exc_info=1)
            return ""

    def _get_exception_stacktrace(self, exception_info):
        try:
            stack_string = io.StringIO()
            traceback.print_exception(*exception_info, file=stack_string)
            return stack_string.getvalue()
        except:
            self.logger.info("Exception on extracting plugin error stacktrace", exc_info=1)
            return ""

    def get_entity_id(self):
        return self.activation_context.entity_id

    def request_fast_check(self, fast_check_id):
        self.fast_check_id = fast_check_id

    def get_fast_status(self):
        ret = self.fast_status_ready, self.fast_check_id
        if self.fast_status_ready:
            self.fast_status_ready = None
            self.fast_check_id = None
        return ret

    def event_disable(self):
        self.logger.info("event_disable (plugin disabled): plugin: %s", self)
        try:
            self.config = None
            self._recreate_engine()
            self.set_full_status(PluginState.DISABLED)
        except Exception:
            self.set_full_status(PluginState.ERROR_UNKNOWN, sys.exc_info())

    def event_uninitialize(self):
        self.logger.info("event_uninitialize (config cleared): plugin: %s", self)
        try:
            self.config = None
            self._recreate_engine()
            self.set_full_status(PluginState.UNINITIALIZED)
        except Exception:
            self.set_full_status(PluginState.ERROR_UNKNOWN, sys.exc_info())

    def event_gather_measurements(self):
        self._execute_next_task()

    def event_set_configuration(self, config):
        self.logger.info(f"event_set_configuration, plugin: {self}")
        self.config = config
        # this looks odd - are we only recreating engine when everything is fine?
        # no - the if statement is to because raising an error already recreates engine
        # so we don't need to do it again
        if PluginStateGroups.is_fine(self.state):
            self._recreate_engine()
        self._execute_next_task()


    #returns True if error is detected and state is set to PluginState.LIMIT_REACHED
    def _handle_limit_error(self)->bool:
        if self.state not in {PluginState.OK, PluginState.LIMIT_REACHED}:
            return False

        if len(self.limits_exceeded) > 0:
            self.set_full_status(PluginState.LIMIT_REACHED, description=self.limits_exceeded[0])
            return True
        else:
            #no limit has been reached
            self.set_full_status(PluginState.OK)
            return False

        
    def _execute_next_task(self):
        start_time = self.external_api.get_timestamp()
        self._last_timestamp = datetime.datetime.fromtimestamp(self.cluster_timestamp)
        self.last_wrapped_results = None
        try:
            self._query_plugin()
            measurements, properties, events = self.results_builder.flush_result()
            self.last_wrapped_results = self._wrap_results(measurements,
                                                           properties,
                                                           events,
                                                           self.external_api.get_timestamp())
            if self.results_builder.was_topx_overflow:
                self.add_limit_exceeded("Number of dimensions exceeded limit for metrics: " + self.results_builder.get_topx_overflow_info)
            self._handle_limit_error()
            self._crash_count = 0
            self._executions_count += 1
        except Exception:
            self._handle_task_exception()
            raise
        finally:
            self._measure_size.reset()
            self._event_count.reset()
            self._properties_limit.reset()
            self._group_properties_limit.reset()
            if self.fast_check_id:
                self.fast_status_ready = self.get_full_status()
            end_time = self.external_api.get_timestamp()
            self._register_stats(start_time, end_time, threading.current_thread().ident)

    def _handle_task_exception(self):
        self._crash_count += 1
        exception_info = sys.exc_info()
        self.set_full_status(
            self._exc_to_state.get(exception_info[0], PluginState.ERROR_UNKNOWN),
            exception_info
        )
        self._recreate_engine()

    def _crash_limit_exceeded(self):
        if self.plugin_info.is_in_development:
            return False
        return self._crash_count >= self._crash_limit

    def _recreate_engine(self):
        if (self._plugin_run_data is not None):
            self._plugin_run_data.plugin_instance.close()
            self._plugin_run_data = None

    def shutdown(self):
        if (self._plugin_run_data is not None):
            self._plugin_run_data.plugin_instance.close()
            self._plugin_run_data = None

    def _register_stats(self, start_time, end_time, thread_id):
        cpu_info = self._get_cpu_stats()
        stats = ExecStat(start_time, end_time, thread_id, cpu_info)
        self._stats.append(stats)

    def get_execution_count(self):
        return self._executions_count

    def get_stats(self):
        if len(self._stats) > 0:
            return self._stats[-1]

    def _get_cpu_stats(self):
        return self.external_api.get_cpu_usage()

    def flush_results(self):
        last_wrapped_results, self.last_wrapped_results = self.last_wrapped_results, None
        return last_wrapped_results

    def select_id(self, **kwargs):
        return self.activation_context.select_id(**kwargs)

    def _wrap_results(self, measurements, properties, events, timestamp)->WrappedResults:
        self._selector_cache = {}
        return WrappedResults(
            measurements=self._wrap_measurements(measurements, timestamp),
            properties=self._wrap_properties(properties),
            events=self._wrap_events(events)
        )

    def _selector_resolve(self, selector):
        if selector not in self._selector_cache:
            self._selector_cache[selector] = self.entity_resolver.resolve(selector, plugin_engine=self)
        return self._selector_cache[selector]

    def _get_aggregation(self, key, metric_metadata, isV3):
            if isV3:
                return 1 # 1 means average "AVG"
            aggregation = metric_metadata.get("source", {"aggregation": "AVG"}).get("aggregation", "AVG")
            aggregation_type = AggregationTypes.__members__.get(aggregation.lower(), None)
            if aggregation_type:
                return aggregation_type.value
            else:
                self.logger.warn("Unrecognized aggregation type: %s for metric: %s", aggregation, key)
                return None

    def _validate_metric_dimensions(self, metric, metric_metadata, isState):
        if isState:
            metadata_timeseries = metric_metadata.get('statetimeseries', None)
        else:
            metadata_timeseries = metric_metadata.get('timeseries', None)
        if not metadata_timeseries:
            self.logger.warn("Unable to find timeseries metric metadata for metric: %s", metric.key)
            return False

        metadata_dimensions = metadata_timeseries.get('dimensions', None)
        if metadata_dimensions is None:
            if metric.dimensions:
                raise Exception("Dimension for metric '" + metric.key + "' provided but not expected.")
        else:
            received_dimensions = [key for key in metric.dimensions]
            if len(metadata_dimensions) != len(received_dimensions):
                raise Exception("Dimensions amount mismatch for metric '" + metric.key + "'. Expected: " +
                                str(len(metadata_dimensions)) + " Received: " + str(len(metric.dimensions)))
            if set(metadata_dimensions) != set(received_dimensions):
                raise Exception("Dimensions mismatch for metric '" + metric.key + "'. Expected: " +
                                str(metadata_dimensions) + " Received: " + str(received_dimensions))
        return True

    def _wrap_measurements(self, measurements, timestamp):
        if not isinstance(measurements, ruxit.api.data.PluginMeasurementList):
            raise TypeError(
                "PluginResults can only be an instance of ruxit.api.PluginMeasurementsList, got %s instead" % type(
                    measurements))

        metrics = []

        for metric in measurements.measurements:
            if self._measure_size.limit_reached: break

            try:
                _, entity_id = self._selector_resolve(metric.entity_selector)
            except Exception:
                self.logger.info("Unable to select entity_id for %s", metric, exc_info=1)
                continue

            metric_value = metric.value
            isState = isinstance(metric, ruxit.api.data.PluginStateMetric)
            if isState:
                state_data = self.states_data.get (metric.key, None)
                if not state_data:
                    self.logger.warning(f"Unable to find state metric metadata for metric: {metric.key}")
                    continue
                if isinstance(metric_value, str):
                    int_value = state_data.states.get(metric_value, None)
                    if int_value is None:
                        self.logger.warning(f"Unknown value for state metric (metric {metric.key} and value {metric_value}) {int_value}"
                                            f"\nAvailable states: {state_data.states}")
                        continue
                    metric_value = float(int_value)
                else:
                    if not metric_value in range (0, len(state_data.states)):
                        self.logger.warning(f"Unknown numeric value for state metric (metric {metric.key} and value {metric_value})"
                                            f"\nAvailable states: {state_data.states}")
                        continue

            isV3 = (not isState) and isinstance(metric, ruxit.api.data.PluginMeasurementV3)
            isStatCounter = (not isState) and isinstance(metric, ruxit.api.data.PluginMeasurementStatCounter)


            if not isV3:
                metric_metadata = self.metadata_by_metric.get(metric.key, None)
                if not metric_metadata:
                    self.logger.warning(f"Unable to find metric metadata for metric: {metric.key}")
                    continue

                if not self._validate_metric_dimensions(metric, metric_metadata, isState):
                    continue

                aggregation = self._get_aggregation(metric.key, metric_metadata, isV3)
                if not aggregation:
                    continue
            else:
                aggregation = self._get_aggregation(metric.key, None, isV3)

            metrics.append(WrappedPluginMeasurement(
                monitoredEntityId=entity_id,
                tsIdentifier=f"{self.plugin_info.reported_name}:{metric.key}",
                dimensions=[Dimension(key=k, value=v) for k, v in metric.dimensions.items()],
                value=metric_value,
                aggregation=aggregation,
                isV3=isV3,
                isStatetimeseries=isState,
                isStatCounter=isStatCounter
            ))
            self._measure_size.increment()

        if self._measure_size.limit_reached:
            status = f"Number of measurements exceeded allowed limit: {self._measure_size.limit}"
            self.add_limit_exceeded(status)

        return WrappedPluginMeasurementList(
            timestamp=measurements.timestamp or timestamp,
            measurements=metrics)


    def _wrap_properties(self, properties):
        limits = collections.defaultdict(lambda: self._properties_limit,
                                        {EntityType.PROCESS_GROUP:self._group_properties_limit,
                                         EntityType.CUSTOM_DEVICE_GROUP:self._group_properties_limit})
        properties_by_meid = collections.defaultdict(list)
        key_limit = None
        value_limit = None
        max_name = self.results_builder.PLUGIN_PROPERTY_NAME_LEN_LIMIT
        max_value = self.results_builder.PLUGIN_PROPERTY_VAL_LEN_LIMIT
        for prop in properties:
            try:
                entity_type, entity_id = self._selector_resolve(prop.entity_selector)
                if ruxit.api.data.PluginProperty.is_custom(prop.me_attribute):
                    #check custom properties limits
                    limit = limits[entity_type]
                    if limit.limit_detected(entity_id, entity_type):
                        continue
                    if prop.key is not None and len(prop.key) >= max_name:
                        key_limit = (entity_id, entity_type, prop.key)
                        continue
                    if len(prop.value) >= max_value:
                        value_limit = (entity_id, entity_type, prop.key)
                        continue
                    limit.increment(entity_id, entity_type)

                entity = ruxit.api.selectors.MeId(metype=entity_type.value, meid=entity_id)
                properties_by_meid[entity].append(CustomPropertyProtoWrapper(
                    key=prop.key, value=prop.value, me_attribute=prop.me_attribute.value))
            except Exception as ex:
                self.logger.info("Unable to set entity_id for {prop} ({ex})", exc_info=1)

        if self._properties_limit.limit_reached:
            limited_entity = next(iter(self._properties_limit.limited_entities.items()))
            self.add_limit_exceeded(f"There is more than {self._properties_limit.limit} properties for"
                                    f" entity {limited_entity[0]} {limited_entity[1]}")
        elif self._group_properties_limit.limit_reached:
            limited_entity = next(iter(self._group_properties_limit.limited_entities.items()))
            self.add_limit_exceeded(f"There is more than {self._group_properties_limit.limit} properties for"
                                    f" entity {limited_entity[0]} {limited_entity[1]}")
        elif key_limit is not None:
            self.add_limit_exceeded(f"Property {key_limit[2]} is too long ({max_name})"
                                    f" for entity {key_limit[0]} {key_limit[1]}")
        elif value_limit is not None:
            self.add_limit_exceeded(f"Property {value_limit[2]} value is too long ({max_value})"
                                    f" for entity {value_limit[0]} {value_limit[1]}")
        return properties_by_meid


    def _wrap_events(self, events):
        wrapped_events = []
        for event in events:
            if self._event_count.limit_reached: break
            try:
                entity_type, entity_id = self._selector_resolve(event.entity_selector)
                event_tile = event.get_value(EventMetadataKey.CUSTOM_TITLE)
                event_id = event.get_correlation_id(entity_id, event.event_type, event_tile) if event.isCorrelated() else event.identifier
                wrapped_event = WrappedEvent(type=event.event_type,
                                             identifier=event_id,
                                             entity_id=entity_id,
                                             me_type=entity_type.value if entity_type else None,
                                             event_metadata=[])
                for event_metadata in event.metadata:
                    wrapped_event.event_metadata.append(WrappedEventMetadata(key=event_metadata.key,
                                                                             value=event_metadata.value,
                                                                             is_boolean=event_metadata.is_boolean,
                                                                             is_float=event_metadata.is_float,
                                                                             is_int=event_metadata.is_int,
                                                                             is_custom_properties=event_metadata.is_custom_properties))
                wrapped_events.append(wrapped_event)
                self._event_count.increment()

            except Exception:
                self.logger.info('Unable to set entity_id for %s', event, exc_info=1)
                continue

        if self._event_count.limit_reached:
            limit_state = f"Number of events exceeded allowed limit: {self._event_count.limit}"
            self.add_limit_exceeded(limit_state)
        event_list = WrappedEventList(events=wrapped_events)
        return event_list
    
    def _query_failed(self, e:Exception):
        #called when plugin query failed to handle exception
        self.set_full_status(
            self._exc_to_state.get(e, PluginState.ERROR_UNKNOWN),
            sys.exc_info()
        )


    def generate_plugin_args(self):
        return {
            'results_builder': self.results_builder,
            'json_config': self.metadata,
            'plugin_info': self.plugin_info,
            'associated_entity': self.activation_context.value,
            'activation_context': self.activation_context,
            'process_snapshot': self.entity_resolver.get_snapshot(),
            'entity_resolver': self.entity_resolver,
            'logger': self.logger,
            'functions': ExternalFunctions(self.external_api.get_agent_version())
        }

    def __repr__(self):
        return "<PluginEngine, meta_name:%s id:%s>" % (self.metadata["name"], hex(id(self)))

    def _create_plugin_run_data(self)->PluginRunData:
        plugin_module = importlib.import_module(self.metadata["source"]["package"])
        plugin_class = getattr(plugin_module, self.metadata["source"]["className"])
        plugin_args = self.generate_plugin_args()
        plugin_args['config'] = copy.deepcopy(self.config)
        data = PluginRunData(
            plugin_class = plugin_class,
            plugin_name = self.metadata["name"],
            plugin_args = plugin_args,
            plugin_instance = plugin_class(**plugin_args))
        return data

    @contextmanager
    def _set_log_system(self):
        if hasattr(self, 'config_id'):
            ruxit.utils._logging.engine_logging.set_plugin_data(
                self._plugin_run_data.plugin_class,
                self._plugin_run_data.plugin_name,
                self.endpoint_name,
                self.config_id)
            level = ruxit.utils._logging.engine_logging.get_log_level(self._plugin_run_data.plugin_name)
            if level is not None: self.logger.setLevel(level) 
        yield
        ruxit.utils._logging.engine_logging.clear_plugin_data()


    def _query_plugin(self):
        if (self._plugin_run_data is None):
            self._plugin_run_data = self._create_plugin_run_data()

        self._plugin_run_data.plugin_args['process_snapshot'] = self.entity_resolver.get_snapshot()
        # state handling based on return values can be added here
        with self._set_log_system() as log_system:
            try:
                self.__limits_exceeded.clear()
                self._plugin_run_data.plugin_instance._query_internal(**self._plugin_run_data.plugin_args)
                if self.execution_timeout:
                    plugin_status = PluginFullStatus(
                        pluginName=self.plugin_info.reported_name,
                        pluginVersion=self.metadata['version'],
                        state=PluginState.ERROR_UNKNOWN.value,
                        description=EXECUTION_TIMEOUT,
                        stacktrace='No stack trace',
                        monitoredEntityId=self.get_entity_id()
                    )
                    self.full_status = plugin_status
                else:
                    self.set_full_status(PluginState.OK)
            except ruxit.api.exceptions.NothingToReportException:
                exception_info = sys.exc_info()
                self.set_full_status(PluginState.NOTHING_TO_REPORT, exception_info)
            except Exception as e:
                self._query_failed(e)
                raise