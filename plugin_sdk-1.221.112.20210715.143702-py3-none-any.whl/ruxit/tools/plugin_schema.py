from ruxit.package_utils.plugin_updater import process_types

UNITS = [
    "NanoSecond",
    "MicroSecond",
    "MilliSecond",
    "Second",
    "Byte",
    "KiloByte",
    "KibiByte",
    "MegaByte",
    "MebiByte",
    "BytePerSecond",
    "BytePerMinute",
    "KiloBytePerSecond",
    "KiloBytePerMinute",
    "KibiBytePerSecond",
    "KibiBytePerMinute",
    "MegaBytePerSecond",
    "MegaBytePerMinute",
    "MebiBytePerSecond",
    "MebiBytePerMinute",
    "Ratio",
    "Percent",
    "Promille",
    "Count",
    "PerSecond",
    "PerMinute",
    "Unspecified",
    "NotApplicable",
]
ENTITY_TYPES = [
    "HOST",
    "PROCESS_GROUP_INSTANCE",
    "PROCESS_GROUP"
]
GENERIC_EVENT_TYPES = [
    "PERFORMANCE_EVENT",
    "AVAILABILITY_EVENT",
    "ERROR_EVENT"
]
GENERIC_EVENT_CONDITION = [
    "ABOVE",
    "BELOW",
]
REQUIRED_TIMESERIES = [
    "key",
    "unit",
    "displayname",
]
REQUIRED_STATE_TIMESERIES = [
    "key",
    "states",
    "displayname",
]


def hack_schema_enum(items):
    """jsonschema doesn't accept case-insensitive enums but dynatrace server does"""
    return [i.capitalize() for i in items] + [i.upper() for i in items] + [i.lower() for i in items]


PROPERTY_TYPES = hack_schema_enum(['STRING', 'BOOLEAN', 'INTEGER', 'FLOAT', 'PASSWORD', 'JSON', 'TEXTAREA', 'DROPDOWN'])
AGGREGATION_TYPES = hack_schema_enum(["MIN", "MAX", "AVG", "SUM", "COUNT", "P50", "P90"])
MERGEAGGREGATION_TYPES = hack_schema_enum(["MIN", "MAX", "AVG", "SUM"])
SERIES_TYPES = hack_schema_enum(["LINE", "AREA", "BAR"])
NAME_PATTERN = r"^([a-zA-Z][a-zA-Z0-9_-]*)(\.[a-zA-Z][a-zA-Z0-9_-]*)*$"
chart_schema = {
    "type": "array",
    "items": {
        "type": "object",
        "required": ["title", "group", "series"],
        "properties": {
            "title": {"type": "string", "minLength": 1},
            "description": {"type": "string", "minLength": 1},
            "group": {"type": "string", "minLength": 1},
            "series": {
                "type": "array",
                "minItems": 1,
                "items": {
                    "type": "object",
                    "required": ["key"],
                    "properties": {
                        "key": {"type": "string", "minLength": 1},
                        "color": {"type": "string"},
                        "aggeragation": {"type": "string", "enum": AGGREGATION_TYPES},
                        "mergeaggregation": {"type": "string", "enum": MERGEAGGREGATION_TYPES},
                        "dimensions": {"type": "array", "minItems": 1, "items": {"type": "string", "minLength": 1}},
                        "seriestype": {"type": "string", "enum": SERIES_TYPES},
                        "stacked": {"type": "boolean"},
                        "rightaxis": {"type": "boolean"},
                        "displayname": {"type": "string", "minLength": 1},
                        "unit": {"type": "string", "minLength": 1},
                    }
                }
            }
        }
    }
}
generic_alert_schema = {
    "type": "array",
    "minItems": 1,
    "items": {
        "type": "object",
        "required": ["event_type", "alert_condition", 'alert_id', 'event_name', 'threshold', 'samples',
                     'violating_samples', 'dealerting_samples'],
        "properties": {

            "event_type": {"type": "string", "enum": GENERIC_EVENT_TYPES},
            "alert_condition": {"type": "string", "enum": GENERIC_EVENT_CONDITION},

            "alert_id": {
                "type": "string", "minLength": 1,
                "pattern": NAME_PATTERN,
            },
            "event_name": {
                "type": "string", "minLength": 1,
            },
            "threshold": {
                "type": "number",
                "minimum": 0
            },
            "samples": {
                "type": "integer",
                "minimum": 3,
                "maximum": 60
            },

            "violating_samples": {
                "type": "integer",
                "minimum": 1
            },
            "dealerting_samples": {
                "type": "integer",
                "minimum": 3
            },
        }
    }
}
CUSTOM_PLUGIN_NAME = r"^custom.(remote\.)?(jmx|pmi|python)(\.[a-zA-Z][a-zA-Z0-9_-]*)+$"
plugin_json_schema = {
    "$schema": "http://json-schema.org/draft-04/schema#",
    "type": "object",
    "required": ["name", "version", "type", "entity", "metrics"],
    "properties": {
        "name": {
            "type": "string", "minLength": 1,
            "description": "The plugin name",
            "pattern": CUSTOM_PLUGIN_NAME,
        },
        "version": {
            "type": "string",
            "description": "The plugin version",
            "pattern": r"^\d+\.\d+(\.\d+)?$",
        },
        "type": {
            "type": "string",
            "description": "The plugin type",
            "enum": ["JMX", "python"],
        },
        "entity": {
            "type": "string",
            "description": "Entity type upon which the plugin is activated",
            "enum": ["PROCESS_GROUP_INSTANCE", "HOST", "CUSTOM_DEVICE", "CUSTOM_DEVICE_GROUP"],
        },
        "processTypes": {
            "type": "array",
            "items": {
                "type": "integer",
                "minimum": 0
            },
            "minItems": 1,
            "uniqueItems": True
        },
        "processTypeNames": {
            "type": "array",
            "items": {
                "enum": [x for x in process_types.keys()],
            },
            "minItems": 1,
            "uniqueItems": True
        },
        "technologies": {
            "type": "array",
            "items": {
                "type": "string"
            },
            "uniqueItems": True
        },
        "metrics": {
            "type": "array",
            "items": {
                "oneOf": [
                    {
                        "type": "object",
                        "required": ["timeseries"],
                        "properties": {
                            "timeseries": {
                                "type": "object",
                                "required": REQUIRED_TIMESERIES,
                                "properties": {
                                    "key": {
                                        "type": "string", "minLength": 1,
                                        "pattern": NAME_PATTERN,
                                    },
                                    "unit": {
                                        "type": "string",
                                        "enum": UNITS
                                    },
                                    "dimensions": {
                                        "type": "array",
                                        "items": {"type": "string", "minLength": 1, "pattern": NAME_PATTERN}
                                    },
                                    "entity": {
                                        "type": "string",
                                        "enum": ENTITY_TYPES
                                    },
                                    "displayname": {
                                        "type": "string", "minLength": 1
                                    }
                                }
                            },
                            "alert_settings": generic_alert_schema

                        }
                    },
                    {
                        "type": "object",
                        "required": ["statetimeseries"],
                        "properties": {
                            "statetimeseries": {
                                "type": "object",
                                "required": REQUIRED_STATE_TIMESERIES,
                                "properties": {
                                    "key": {
                                        "type": "string", "minLength": 1,
                                        "pattern": NAME_PATTERN,
                                    },
                                    "dimensions": {
                                        "type": "array",
                                        "items": {"type": "string", "minLength": 1, "pattern": NAME_PATTERN}
                                    },
                                    "states": {
                                        "type": "array",
                                        "items": {"type": "string", "minLength": 1, "pattern": NAME_PATTERN}
                                    },

                                    "entity": {
                                        "type": "string",
                                        "enum": ENTITY_TYPES
                                    },
                                    "displayname": {
                                        "type": "string", "minLength": 1
                                    }
                                }
                            }
                        },
                        "alert_settings": generic_alert_schema
                    },
                ]
            },
        },
        "properties": {
            "type": "array",
            "items": {
                "type": "object",
                "required": ["key", "type"],
                "properties": {
                    "key": {"type": "string", "minLength": 1},
                    "type": {"type": "string", "enum": PROPERTY_TYPES}
                }
            }
        },
        "ui": {
            "type": "object",
            "properties": {
                "keyMetrics": {
                    "type": "array",
                    "minItems": 0,
                    "maxItems": 2,
                    "items": {
                        "type": "object",
                        "required": ["key"],
                        "properties": {
                            "key": {"type": "string", "minLength": 1},
                            "aggregation": {"type": "string", "enum": AGGREGATION_TYPES},
                            "mergeaggregation": {"type": "string", "enum": MERGEAGGREGATION_TYPES},
                            "displayname": {"type": "string", "minLength": 1}
                        }
                    }
                },
                "keycharts": chart_schema,
                "charts": chart_schema
            }
        },
        "configUI": {
            "type": "object",
            "properties": {
                "displayName": {"type": "string", "minLength": 1},
                "properties": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "key": {"type": "string", "minLength": 1},
                            "displayName": {"type": "string", "minLength": 1},
                            "displayOrder": {"type": "integer", "minimum": 1},
                        }
                    }
                }
            }
        },
        "source": {},
    },
}
