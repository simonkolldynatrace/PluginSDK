import logging
import pkg_resources
import collections
import re
import operator
import json
import pprint
import pathlib

from typing import List
from ruxit.messages import DUPLICATE

log = logging.getLogger(__name__)
PLUGIN_DEVELOPMENT_DIRNAME = 'plugin_development'
PLUGIN_DEPLOYMENT_DIRNAME = 'plugin_deployment'
process_types = {'UNKNOWN':0,
               'LINUX_SYSTEM':1,
               'ORACLE_DB':2,
               'APACHE_HTTPD':3,
               'WINDOWS_SYSTEM':4,
               'WINDOWS_SERVICE':5,
               'MSSQL':6,
               'DB2':7,
               'IIS':8,
               'MYSQL':9,
               'JAVA':10,
               'DOTNET':11,
               'TOMCAT':12,
               'WEBSPHERE':13,
               'APMNG':14,
               'ALLOTHER':15,
               'JBOSS':16,
               'WEBLOGIC':17,
               'GLASSFISH':18,
               'IIS_APP_POOL':19,
               'POSTGRES':20,
               'MONGODB':21,
               'CASSANDRA':22,
               'MEMCACHED':23,
               'COUCHDB':24,
               'REDIS':25,
               'RUBY':26,
               'PERL':27,
               'NODE_JS':28,
               'PYTHON':29,
               'NGINX':30,
               'VARNISH_CACHE':31,
               'HAPROXY':32,
               'PHP':33,
               'AWS_RDS':34,
               'ERLANG':35,
               'DOCKERDEAMON':36,
               'MONGODB_ROUTER':37,
               'GO':38,
               'SAP':39
               }


class PluginInfo:
    def __init__(self, json_data, directory):
        self.json_data = json_data
        self.name = json_data['name']
        self.version = json_data['version']
        self.directory = directory
        self.compatibility_errors = []
        self._is_development = PLUGIN_DEVELOPMENT_DIRNAME in pathlib.Path(self.directory).parts
        self.reported_name = json_data['name'] if not self._is_development else json_data['name']+'.dev'
        self.process_types = []
        if 'processTypeNames' in json_data:
            #convert process type names into integer type
            self.process_types = self._convert_process_type(json_data['processTypeNames'])
        if len(self.process_types) == 0 and 'processTypes' in json_data:
            raw_process_types = json_data['processTypes'] 
            if isinstance (raw_process_types, list) and len(raw_process_types) != 0:
                #in case of failure process names old integer process types are used
                self.process_types = raw_process_types
        self.technologies = [x.lower() for x in json_data.get('technologies', [])]
        json_source = json_data.get('source', {})
        self._name_pattern = json_source.get ('activation_name_pattern', None) or json_source.get('activation_pgi_name_pattern', None)
        self.entity_type = self.json_data.get('entity', 'PROCESS_GROUP_INSTANCE')
        self.package = json_source.get('package',"")
        self.topx_data = {k["timeseries"]["key"]: k["timeseries"].get("topx", 100) * 10 for k in json_data.get("metrics", []) if "timeseries" in k}

    def _convert_process_type(self, types_list):    
        return [process_types[type_name] for type_name in types_list if type_name in process_types]
        
    @property
    def is_process_group_instance (self):
        return self.entity_type == 'PROCESS_GROUP_INSTANCE'

    @property
    def technologies_case_sensitive(self) -> List[str]:
        return self.json_data.get('technologies', [])


    @property
    def associated_process_types(self):
        if self.is_process_group_instance:
            return self.process_types
        else:
            return []

    @property
    def associated_technologies(self):
        return self.technologies

    @property
    def name_pattern(self):
        if self.is_process_group_instance and self._name_pattern:
            return self._name_pattern
        else:
            return ''

    @property
    def is_in_development(self):
        return self._is_development

    def __eq__(self, other):
        if isinstance(other, type(self)):
            return self.name == other.name and self.version == other.version and self.json_data == other.json_data
        return NotImplemented

    def __repr__(self):
        return "PluginInfo(name=%r, reported_name=%r, version=%r, directory=%r  package=%r)" % \
               (self.name, self.reported_name, self.version, self.directory,self.package)


class PluginUpdater:
    def __init__(self, initial_entries, all_plugins):
        self.initial_entries = initial_entries
        self.current_entries = collections.OrderedDict()
        self.plugins_by_revision = collections.defaultdict(dict)
        self.incompatible_plugins = []
        for plugin_dir, plugin_json_str in all_plugins:
            rev = self._get_revision(plugin_dir)
            plugin_json = json.loads(plugin_json_str)
            plugin_info = PluginInfo(json_data=plugin_json, directory=plugin_dir)
            self.plugins_by_revision[rev][plugin_info.name] = plugin_info
        log.info("plugins_by_revision: %s", pprint.pformat(self.plugins_by_revision))

    @staticmethod
    def _get_revision(plugin_directory_path):
        try:
            pattern = 'rev(?P<rev_number>\d+)$'
            plugin_rev_dir = pathlib.Path(plugin_directory_path).parts[-2]
            m = re.match(pattern, plugin_rev_dir)
            return int(m.group('rev_number'))
        except Exception as ex:
            if PLUGIN_DEVELOPMENT_DIRNAME in plugin_directory_path:
                log.info("Development plugin detected in %r", plugin_directory_path)
                return 'plugin_development'
            elif PLUGIN_DEPLOYMENT_DIRNAME in plugin_directory_path:
                log.info("External deployment plugin detected in %r", plugin_directory_path)
                return 'plugin_deployment'
            log.info("Unable to get revision from plugin_directory_path %r, assuming -1", plugin_directory_path)
            return 'no_revision'

    def revisions_newest_to_oldest(self):
        for rev in sorted((k for k in self.plugins_by_revision.keys() if not isinstance(k, str)), reverse=True):
            yield rev, self.plugins_by_revision[rev]
        yield 'no_revision', self.plugins_by_revision.get('no_revision', {})
        yield 'plugin_deployment', self.plugins_by_revision.get('plugin_deployment', {})
        yield 'plugin_development', self.plugins_by_revision.get('plugin_development', {})


    def install_plugins(self):
        log.info("Installing plugins")
        for revision, candidate_plugin_entries in self.revisions_newest_to_oldest():
            try:
                log.info("Processing revision %r", revision)
                for plugin_name, plugin_info in sorted(candidate_plugin_entries.items(), key=operator.itemgetter(0)):
                    if plugin_name not in self.current_entries:
                        compat_status, compat_errors = self._update_working_set({plugin_name: plugin_info})
                        if compat_status:
                            log.info('Plugin %r from revision %r compatible', plugin_info, revision)
                        else:
                            log.info('Plugin %r from revision %r is not compatible', plugin_info, revision)
                            plugin_info.compatibility_errors = compat_errors
                            self.incompatible_plugins.append(plugin_info)
                    else:
                        log.info("Plugin %s not loaded as newer version is already selected", plugin_info)
            except Exception:
                log.exception('Exception at processing revision')
        return list(reversed(list(self.current_entries.values())))

    def _update_working_set(self, candidate_entries):
        log.info(
            'Processing candidate_entries: %s',
            pprint.pformat(candidate_entries),
        )

        new_entries, errors = self._check_candidate_working_set(self.current_entries, candidate_entries)
        if not errors:
            self.current_entries = new_entries
            log.info("Working set validated, new current_entries: %s", pprint.pformat(self.current_entries))
            return True, []
        log.info('='*40)
        log.info("Plugins %s installation caused errors: %s", pprint.pformat(candidate_entries), pprint.pformat(errors))
        log.info('='*40)
        return False, errors

    def _check_candidate_working_set(self, current_entries, new_entries):
        candidate_entries = collections.OrderedDict(current_entries.items())
        errors = []
        for plugin_name, plugin_info  in new_entries.items():
            candidate_entries.pop(plugin_name, None)
            candidate_entries[plugin_name] = plugin_info
            try:
                for name,info in current_entries.items():
                    if plugin_info.package == info.package:
                        raise DuplicatedPackageNameException(DUPLICATE % (plugin_name,name))
            except DuplicatedPackageNameException as ex:
                errors.append(ex)
        entries_newest_to_oldest = list(reversed([entry.directory for entry in candidate_entries.values()]))
        log.debug("Resolving entries: %s", pprint.pformat(entries_newest_to_oldest))
        candidate_ws = pkg_resources.WorkingSet(self.initial_entries + entries_newest_to_oldest)
        #errors = []
        for dist in candidate_ws:
            try:
                candidate_ws.resolve([dist.as_requirement()], env=pkg_resources.Environment([]))
            except BaseException as ex:
                log.error(f'Resolving distribution failed because of {ex}\n'+
                          f'project: {dist.project_name}\n'+
                          f'version: {dist.version}\n'+
                          f'path: {dist.module_path}\n'+
                          f'location: {dist.location}')
                errors.append(ex)
        return candidate_entries, errors


class DuplicatedPackageNameException(Exception):
    pass


