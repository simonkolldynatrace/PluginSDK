import os
import os.path
import logging
import sys
import time
log = logging.getLogger(__name__)

class PlopDriver:
    DEFAULT_DURATION_S = 600
    DEFAULT_INTERVAL_MS = 100
    DEFAULT_INTERVAL_S = DEFAULT_INTERVAL_MS / 1000

    def __init__(self, external_api):
        self.external_api = external_api
        self.use_plop = None
        self.plop_started_timestamp = None
        self.duration = PlopDriver.DEFAULT_DURATION_S

    def step(self):
        if sys.platform != 'win32':
            self.configure_plop()

    def configure_plop(self):
        plop_enabled = self.external_api.get_bool_debug_flag("debugPluginAgentPlopEnabledNative", False)
        if plop_enabled and self.use_plop is None:
            plop_interval = self.external_api.get_int_debug_flag(
                "debugPluginAgentPlopIntervalMilisecondsNative",
                PlopDriver.DEFAULT_INTERVAL_MS) / 1000
            if plop_interval <= 0:
                plop_interval = PlopDriver.DEFAULT_INTERVAL_S
            plop_duration = self.external_api.get_int_debug_flag(
                "debugPluginAgentPlopDurationSecondsNative",
                PlopDriver.DEFAULT_DURATION_S
            )
            if plop_duration <= 0:
                plop_duration = PlopDriver.DEFAULT_DURATION_S
            plop_mode = self.external_api.get_str_debug_flag("debugPluginAgentPlopModeNative", "virtual")
            if plop_mode not in {"real", "prof", "virtual"}:
                plop_mode = 'virtual'
            self.plop_started_timestamp = time.monotonic()
            self.duration = plop_duration
            self.use_plop = UsePlop(
                prof_stats_dir=self.external_api.get_log_path(),
                interval=plop_interval,
                duration=plop_duration,
                mode=plop_mode
            )
        elif plop_enabled and self.use_plop:
            # plop running is based on number of samples taken which is not very accurate,
            # so additional wall clock calculation make the sampling periods more accurate
            now = time.monotonic()
            if now - self.plop_started_timestamp > self.duration:
                self._reset_plop()
        elif plop_enabled and self.use_plop and not self.use_plop.is_running:
            self._reset_plop()
        elif not plop_enabled and self.use_plop:
            self._reset_plop()

    def _reset_plop(self):
        self.use_plop = None
        self.plop_started_timestamp = None


class UsePlop:
    def __init__(self, *, prof_stats_dir, interval=PlopDriver.DEFAULT_INTERVAL_S, mode='virtual', duration=PlopDriver.DEFAULT_DURATION_S):
        import plop.collector
        log.info(
            "starting plop.collector, interval=%s, mode=%s, duration=%s",
            interval,
            mode,
            duration
        )
        self.prof_stats_dir = prof_stats_dir
        self.collector = plop.collector.Collector(
            interval=interval,
            mode=mode
        )
        self.collector.start(duration=duration)

    @property
    def is_running(self):
        return not self.collector.stopped

    def __del__(self):
        import plop.collector
        log.info("turning off plop.collector and saving data")
        self.collector.stop()
        if self.collector.samples_taken:
            pid = os.getpid()
            timestamp = str(time.monotonic()).replace('.', "_")
            flame_file_path = os.path.join(self.prof_stats_dir, "agentplugin_plop_flame_%s_%s" % (pid, timestamp))
            flame_formatter = plop.collector.FlamegraphFormatter()
            flame_formatter.store(self.collector, flame_file_path)
            log.info("plop output (flamegraph format) saved to %s" % flame_file_path)
            log.info(
                "plop overall time %s, samples taken %s, time per sample: %s",
                self.collector.sample_time,
                self.collector.samples_taken,
                self.collector.sample_time / self.collector.samples_taken,
            )
        else:
            log.info("No plop output generated, as there were no samples")

