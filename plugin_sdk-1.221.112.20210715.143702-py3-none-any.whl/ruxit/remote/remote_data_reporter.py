import sys
import time
from ruxit.plugin_status_reporter import PluginState
from .remote_result_builder import DataReporter

class RemoteDataReporter(DataReporter):
    
    #number of tries to send metrics
    RETRIES_COUNT = 3
    LAST_RETRY = RETRIES_COUNT -1
    RETRY_DELAY = 3
    
    def __init__(self, remote_plugin):
        self._remote_plugin = remote_plugin
        self._error_detected = None


    #called after query end to reset status data
    def report_reset(self)->None:
        if self._error_detected:
            self._remote_plugin.set_full_status(PluginState.ERROR_UNKNOWN, self._error_detected)
        self._error_detected = None


    def report_data(self):
        #report topology
        if not self._remote_plugin.is_fast_check:
            try:
                self._remote_plugin.topology_builder.set_clear_after_flush(False)
                self._remote_plugin._remote_api.additional_report_step(self._remote_plugin)
            except:
                self._error_detected = sys.exc_info()
            finally:
                self._remote_plugin.topology_builder.set_clear_after_flush(True)

            #report data
            measurements, properties, events = self._remote_plugin.results_builder.partial_flush()
            results = self._remote_plugin._wrap_results(measurements, properties, events,
                                                        self._remote_plugin.external_api.get_timestamp())
            if not self._remote_plugin._handle_limit_error() and not self._error_detected:
                self._remote_plugin.set_full_status(PluginState.OK)

            for i in range(0,RemoteDataReporter.RETRIES_COUNT):
                try:
                    self._remote_plugin.external_api.report_results(
                        results.measurements,
                        results.properties,
                        results.events.events
                    )
                    break
                except Exception as ex:
                    if i >= RemoteDataReporter.LAST_RETRY:
                        self._remote_plugin.get_logger().info("Report results is stopped (plugin %s threw exception %s)",
                                                              self._remote_plugin, ex)
                        self._error_detected = sys.exc_info()
                        self._remote_plugin.set_full_status(PluginState.ERROR_UNKNOWN, self._error_detected)
                        break;
                    else:
                        #async message buffer is freed after 3 seconds
                        self._remote_plugin.get_logger().info("Reporting results is suspended for %d seconds (plugin %s threw exception %s)",
                                                              RemoteDataReporter.RETRY_DELAY, self._remote_plugin, ex)
                        time.sleep(RemoteDataReporter.RETRY_DELAY)
        else:
            self._remote_plugin.get_logger().info("Results are not reported - fast check.")
            self._remote_plugin.topology_builder._groups = {}
            self._remote_plugin.results_builder.reset_result()
