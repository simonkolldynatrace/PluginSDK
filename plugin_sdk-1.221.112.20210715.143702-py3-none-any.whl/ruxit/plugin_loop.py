import json, sys, logging, logging.handlers, time, pprint, itertools, traceback, collections
from pathlib import Path
import ruxit.plugin_state_machine, ruxit.config_utils, ruxit.plugin_status_reporter
import ruxit.mem_tracking,ruxit.utils.fault_handling,  ruxit.utils.perf_utils
import ruxit.utils.murmur3, ruxit.utils._logging

from .utils.execute_every_minute import ExecuteEveryMinute
from .package_utils import plugin_updater as plugin_update_mod
from ruxit.plugin_status_reporter import PluginFullStatus, PluginState
from ruxit.utils._logging import engine_logging
from ruxit.utils.docker_helper import DockerUtils


logger = logging.getLogger(__name__)

def _do_nothing(self, *args, **kwargs):
    pass


class PluginTask:
    def __init__(self, engine, follow_up=None, timestamp=None):
        self.engine = engine
        self.follow_up = follow_up
        self.created_timestamp = timestamp
        if timestamp is None:
            self.created_timestamp = time.monotonic()
        if follow_up is None:
            self.follow_up = _do_nothing

    def __repr__(self):
        return "PluginTask(engine=%s,follow_up=%s,created_timestamp=%s" % (
            self.engine,
            self.follow_up,
            self.created_timestamp
        )


class PluginLoop:
    SfmStat = collections.namedtuple('SfmStat', ['cpu_usage', 'mem_used', 'exec_time'])
    def __init__(self,
                 concurrent_mod,
                 stop_strategy,
                 report_results_strategy,
                 get_metadata_strategy,
                 platform_api,
                 num_python_threads):

        self.pending_disabled = []
        self.concurrent_mod = concurrent_mod
        self.executor = self.concurrent_mod.ThreadPoolExecutor(max_workers=num_python_threads)

        self.step_timeout = 2
        self.shutdown_timeout = 8

        self.plugin_engines = []
        self.incompatible_plugins = []
        self.pending_execution = []
        self.submitted_tasks = {}

        self.latest_plugin_infos = []

        self.report_results_strategy = report_results_strategy
        self.get_metadata_strategy = get_metadata_strategy
        self.stop_strategy = stop_strategy
        self.platform_api = platform_api

        self.status_every_minute = ExecuteEveryMinute()
        self.sfm_every_minute = ExecuteEveryMinute()
        self.zero_counter_every_minute = ExecuteEveryMinute()
        self.plugin_reporter = ruxit.plugin_status_reporter.PluginStatusReporter(self.platform_api.external_api)

        self.mem_driver = ruxit.mem_tracking.TracemallocDriver(external_api=self.platform_api.external_api)

        log_path = self.platform_api.external_api.get_log_path()
        install_path = self.platform_api.external_api.get_install_path()
        self.fault_handler_trap = ruxit.utils.fault_handling.FaultHandlerTrap(fault_info_dir=log_path)
        self.hung_plugin_reporter = ruxit.utils.fault_handling.HungPluginsReporter(fault_info_dir=log_path)
        self.plop_driver = ruxit.utils.perf_utils.PlopDriver(external_api=self.platform_api.external_api)
        ruxit.utils.murmur3.Murmur3().initialize(self.platform_api.external_api, platform_api.is_local)
        self.run_plugins = set()
        DockerUtils.base_path = Path(install_path)

    def main(self):
        self._update_logging_configuration()
        self._update_plugin_metadata()
        process_mem = self._create_processmem()

        while self.should_run():
            time_start = time.monotonic()

            if not self.platform_api.external_api.should_pause():
                process_mem()
                self.one_plugin_loop_step()
            self.plop_driver.step()

            work_time = time.monotonic() - time_start
            time_left = self.step_timeout - work_time
            if time_left > 0:
                time.sleep(time_left)

            self.status_every_minute.do(
                logger.info,
                "Plugin loop status: time_taken: %s, engines_info: %s, ",
                work_time,
                pprint.pformat(["%s, executions:%s " % (pe, pe.get_execution_count()) for pe in self.plugin_engines]),
            )

            if not self.platform_api.is_local:
                self.sfm_every_minute.do(
                    self.report_self_monitoring,
                    self.platform_api,
                    self.plugin_engines,
                )
                self.zero_counter_every_minute.do(
                    self.zero_counter,
                    self.plugin_engines,
                )

        self.shutdown()

    def zero_counter(self, endpoints):
        for endpoint in endpoints:
            endpoint.device_counter = 0
            endpoint.group_counter = 0


    def report_self_monitoring(self, platform_api, plugins):
        cpu = platform_api.external_api.get_cpu_usage()
        mem = platform_api.external_api.get_mem_usage()
        execTimeList = []
        for plugin in plugins:
            if len(plugin._stats) > 0:
                pluginName = plugin.plugin_info.name + " " + str(plugin.config_id)
                execTime = plugin._stats[-1].end_time - plugin._stats[-1].start_time
                logger.debug("SFM stat: Plugin: %s, exec time=%d", pluginName, execTime)
                execTimeList.append((pluginName, execTime))

        stat = self.SfmStat(cpu_usage=cpu, mem_used=mem, exec_time=execTimeList)
        platform_api.external_api.report_self_monitoring(stat)

    def _create_processmem(self):
        mem_driver_interval = self.platform_api.external_api.get_int_debug_flag(
            "debugPluginAgentTracemallocIntervalNative",
            180
        )
        process_mem = ruxit.mem_tracking.run_on_interval_decorator(
            lambda: self.mem_driver.process_memory_usage(),
            mem_driver_interval
        )
        return process_mem

    def one_plugin_loop_step(self):
        self._update_logging_configuration()
        if self.platform_api.data_update():
            self.trigger_plugins_life(self.latest_plugin_infos)
        self._update_plugin_log_level()
        self.trigger_state_machines()

        done_futures, not_done_futures = self.concurrent_mod.wait(self.submitted_tasks.keys(), timeout=self.step_timeout)
        for done_future in done_futures:
            plugin_task = self.submitted_tasks[done_future]
            plugin_engine = plugin_task.engine
            plugin_engine.execution_timeout = False
            del self.submitted_tasks[done_future]
            try:
                # in order to catch exceptions originating from plugins
                done_future.result()
                plugin_task.follow_up(plugin_engine)
            except Exception as ex:
                plugin_engine.get_logger().info("plugin %s threw exception %s", plugin_engine, ex)

            if plugin_engine not in self.pending_disabled:
                self.pending_execution.append(plugin_engine)
            else:
                self.pending_disabled.remove(plugin_engine)

        self.hung_plugin_reporter.report_hung_tasks(self.submitted_tasks)

        self.gather_stats()

        self.report_plugins_status()

        return done_futures, not_done_futures

    def _report_plugin_results(self, plugin_engine):
        result = plugin_engine.flush_results()
        if result is None:
            plugin_engine.get_logger().warn("No results available from plugin_engine %s" % plugin_engine)
            return
        if plugin_engine.get_logger().isEnabledFor(logging.DEBUG):
            plugin_engine.get_logger().info("Plugin finished engine=%s, result=%s", plugin_engine, pprint.pformat(result))
            
        if not plugin_engine.is_fast_check:
            try:
                self.report_results_strategy(
                    result.measurements,
                    result.properties,
                    result.events.events
                )
            except Exception as ex:
                plugin_engine.get_logger().info("Report results for plugin %s threw exception %s", plugin_engine, ex)
                exception_info = sys.exc_info()
                plugin_engine.set_full_status(PluginState.ERROR_UNKNOWN, exception_info)

            self.platform_api.additional_report_step(plugin_engine)
        else:
            logging.info("Results are not reported - fast check.")
            if not self.platform_api.is_local:
                plugin_engine.topology_builder._groups = {}
            plugin_engine.results_builder.reset_result()


    def _update_plugin_metadata(self):
        updated_metadata = self.get_metadata_strategy()
        if self.platform_api.external_api.resolve_conflicts_flag():
            logger.info('Installing plugins with conflict resolution')
            plugin_updater = plugin_update_mod.PluginUpdater(
                sys.path,
                updated_metadata
            )
            plugin_entries = plugin_updater.install_plugins()
            self.incompatible_plugins = plugin_updater.incompatible_plugins
            logger.info('========= INCOMPATIBLE PLUGINS =========')
            logger.info(pprint.pformat(self.incompatible_plugins))
            logger.info('='*40)
            logger.info('*'*40)
            logger.info(plugin_entries)
            logger.info('*'*40)
            self.latest_plugin_infos = plugin_entries
            sys.path.extend([entry.directory for entry in plugin_entries])
            logger.info("sys.path after installing plugins: %r", sys.path)
        else:
            logger.info("Installing plugins using old mechanism (no conflict resolution)")
            self.latest_plugin_infos = [
                plugin_update_mod.PluginInfo(json_data=json.loads(mt[1]), directory=mt[0]) for mt in updated_metadata
            ]
            for directory_metadata in updated_metadata:
                if directory_metadata[0] not in sys.path:
                    sys.path.append(directory_metadata[0])
                    logger.info('appending %s to sys.path', directory_metadata[0])
        if logger.isEnabledFor(logging.DEBUG):
                    logger.debug("Latest plugin metadata: %s", pprint.pformat(self.latest_plugin_infos))

    def trigger_plugins_life(self, plugin_metadata):
        to_activate, to_deactivate = self.platform_api.select_plugins(self.plugin_engines, plugin_metadata)
        plugins_changed = False
        for engine_activation_context, plugin_info in to_activate:
            try:
                plugins_changed = True

                engine = self.platform_api.create_engine(plugin_info, engine_activation_context)
                logger.info(
                    "Activating plugin engine: %s \ninfo: %s",
                    engine,
                    plugin_info
                )
                if engine.get_logger().isEnabledFor(logging.DEBUG):
                    engine.get_logger().debug("Activated engine full metadata: %s", pprint.pformat(plugin_info.json_data))
                self.pending_execution.append(engine)
                self.plugin_engines.append(engine)
                self.run_plugins.add(engine.metadata["name"])
            except:
                logger.exception ("Unable to create plugin %s because of %s",
                                  'plugin_info.json_data.metadata["source"]["className"]',
                                  sys.exc_info())

        for inactive_engine in to_deactivate:
            plugins_changed = True
            inactive_engine.get_logger().info(
                    "Removing plugin engine: %s, activation_context: %s",
                    inactive_engine,
                    inactive_engine.activation_context
            )
            self.plugin_engines.remove(inactive_engine)
            self.plugin_reporter.remove_engine(inactive_engine)
            if inactive_engine in self.pending_execution:
                self.pending_execution.remove(inactive_engine)
            else:
                self.pending_disabled.append(inactive_engine)

        if plugins_changed:
            logger.info("active plugins changed")

    def trigger_state_machines(self):
        new_pending_execution = []
        for plugin_engine in self.pending_execution:
            future = None
            follow_up = None
            new_config, fast_check_id, enabled = self.platform_api.get_plugin_config(plugin_engine, self.latest_plugin_infos)

            if fast_check_id:
                plugin_engine.request_fast_check(fast_check_id)
            plugin_uninitialized = not plugin_engine.is_initialized()
            if enabled and plugin_engine.ready_for_set_config(new_config, fast_check_id):
                future = self.executor.submit(
                    plugin_engine.event_set_configuration,
                    new_config
                )
                follow_up = self._report_plugin_results
            elif new_config is not None and not enabled and plugin_engine.state != PluginState.DISABLED:
                future = self.executor.submit(plugin_engine.event_disable)
            elif new_config is None and not plugin_uninitialized:
                future = self.executor.submit(plugin_engine.event_uninitialize)
            elif plugin_engine.ready_for_measure():
                future = self.executor.submit(plugin_engine.event_gather_measurements)
                follow_up = self._report_plugin_results

            if future is not None:
                self.submitted_tasks[future] = PluginTask(plugin_engine, follow_up=follow_up)
            else:
                new_pending_execution.append(plugin_engine)

        self.pending_execution = new_pending_execution

    def shutdown(self):
        logger.info("Shutting down plugin loop")
        not_cancelled = []
        cancelled = []

        # cancel plugins that can be cancelled
        for future in self.submitted_tasks:
            cancel_result = future.cancel()
            if not cancel_result:
                not_cancelled.append(future)
            else:
                cancelled.append(future)
        # wait for all executing plugins
        done, not_done = self.concurrent_mod.wait(not_cancelled, timeout=self.shutdown_timeout)

        # schedule closing of all plugins
        shutdown_tasks = []
        for future in itertools.chain(cancelled, done):
            plugin_engine = self.submitted_tasks[future].engine
            future = self.executor.submit(plugin_engine.shutdown)
            shutdown_tasks.append(future)
        # wait for them to shut down
        shut_down, not_shut_down = self.concurrent_mod.wait(shutdown_tasks, timeout=self.shutdown_timeout)

        self.executor.shutdown(wait=False)
        logger.info("Plugin loop shutdown finished")

    def gather_stats(self):
        for engine in self.plugin_engines:
            if engine.get_logger().isEnabledFor(logging.DEBUG):
                engine.get_logger().debug('Plugin Stats for engine %s: \n%s', engine, pprint.pformat(engine.get_stats()))

    def should_run(self):
        return next(self.stop_strategy) and self.platform_api.external_api.plugins_enabled()

    def report_plugins_status(self):
        not_existing_plugins = self.platform_api.get_not_existing_plugins(self.plugin_engines)
        self.plugin_reporter.report_status(
            engines = reversed(self.plugin_engines), 
            incompatible_plugins = self.incompatible_plugins,
            not_existing_plugins = not_existing_plugins)

    def _update_logging_configuration(self):
        # we're setting this on root logger, so all other loggers are affected
        if self. platform_api.external_api.is_debug_logging_enabled() is True:
            logging.getLogger().setLevel(logging.DEBUG)
        else:
            logging.getLogger().setLevel(logging.INFO)


    def _update_plugin_log_level(self):
        for plugin_name in self.run_plugins:
            log_level = self.platform_api.external_api.get_str_debug_flag('debugRPACustomLogLevel.{}'.format(plugin_name), 'NONE')
            if log_level != 'NONE':
                engine_logging.set_log_level(plugin_name, log_level)


def dump_stack():
    code = []
    for threadId, stack in sys._current_frames().items():
        code.append("\n# Thread: %d" % (threadId))
        for filename, lineno, name, line in traceback.extract_stack(stack):
            code.append('File: "%s", line %d, in %s' % (filename, lineno, name))
            if line:
                code.append("  %s" % (line.strip()))
    logger.info("\n".join(code))
    return code


def main(stop_strategy, report_results_strategy, get_metadata_strategy, platform_api, num_python_threads):
    import concurrent.futures
    import concurrent.futures.thread
    import atexit
    atexit.unregister(concurrent.futures.thread._python_exit)
    loop = PluginLoop(
        stop_strategy=stop_strategy,
        concurrent_mod=concurrent.futures,
        report_results_strategy=report_results_strategy,
        get_metadata_strategy=get_metadata_strategy,
        platform_api=platform_api,
        num_python_threads=num_python_threads)
    loop.main()
