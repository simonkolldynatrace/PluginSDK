import logging

log = logging.getLogger(__name__)


def get_version():
    try:
        import plugin_sdk.version
        __version__ = plugin_sdk.version.__version__
    except Exception:
        log.debug("Unable to get the tool version", exc_info=1)
        __version__ = '9.999.999.dev0'
    return __version__


def get_short_version():
    v = get_version()
    return '.'.join(v.split('.')[:2])
