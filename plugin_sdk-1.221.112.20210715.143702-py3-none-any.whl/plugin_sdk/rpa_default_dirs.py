import sys
import os
import logging

log = logging.getLogger(__name__)

DYNATRACE_REGISTRY = "SOFTWARE\\Dynatrace\\Dynatrace ActiveGate\\common"
INSTALL_DIR_KEY = "install.dir"
CONFIG_DIR_KEY = "conf.dir"
LINUX_FUNCTIONS_FILE = "/etc/init.d/dynatracefunctions"


def get_default_installation_dir():
    """
    Returns default installation directory for Remote Plugin Agent. It should return
    C:/ProgramFiles/dynatrace/remotepluginmodule for Windows and /opt/dynatrace/remotepluginmodule for Linux

    :rtype: str
    :return: remote plugin agent installation directory
    """
    if sys.platform == "win32":
        install_dir = get_dir_from_registry(
            "SOFTWARE\\Dynatrace\\Dynatrace ActiveGate\\common", INSTALL_DIR_KEY
        )
        if install_dir is not None:
            ret = os.path.join(install_dir, "remotepluginmodule")
        else:
            ret = os.getcwd()
    else:
        install_dir = get_dir_from_file("INSTALL_DIR=")
        if install_dir is not None:
            ret = os.path.join(install_dir, "remotepluginmodule")
        else:
            ret = os.getcwd()
    logging.debug("Setting installation root dir to %s", ret)
    return ret


def get_default_config_persistence_dir():
    """
    Returns default config persistence for Remote Plugin Agent where all files created by agent will be stored. It
    should return C:/ProgramData/dynatrace/remotepluginmodule/agent/conf for Windows and
    /var/lib/dynatrace/remotepluginmodule/agent/conf for Linux

    :rtype: str
    :return: remote plugin agent storage directory
    """
    if sys.platform == "win32":
        config_dir = get_dir_from_registry(
            "SOFTWARE\\Dynatrace\\Dynatrace ActiveGate\\common", CONFIG_DIR_KEY
        )
        if config_dir is not None:
            ret = os.path.join(config_dir, "remotepluginmodule", "agent", "conf")
        else:
            ret = os.path.join(
                os.environ["programdata"],
                "dynatrace",
                "remotepluginmodule",
                "agent",
                "conf",
            )
    else:
        config_dir = get_dir_from_file("CONFIG_DIR=")
        if config_dir is not None:
            ret = os.path.join(config_dir, "remotepluginmodule", "agent", "conf")
        else:
            ret = os.path.join(
                os.path.sep,
                "var",
                "lib",
                "dynatrace",
                "remotepluginmodule",
                "agent",
                "conf",
            )
    logging.debug("Setting persistence config dir to %s", ret)
    return ret


def get_dir_from_registry(reg_path, key):
    """
    Returns installation directory read from Remote Plugin Registry on Windows. This function reads 'Path' value from RPA registry

    :rtype: str
    :return: remote plugin agent installation directory
    """
    import winreg

    try:
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, reg_path, 0, winreg.KEY_READ | winreg.KEY_WOW64_64KEY) as k:
            log_path = winreg.QueryValueEx(k, key)
            return log_path[0]
    except:
        log.debug(
            "Could not read installation directory from registry key %s, falling back to default, details:",
            reg_path,
            exc_info=1,
        )
    return None


def get_dir_from_file(parameter):
    try:
        with open(LINUX_FUNCTIONS_FILE) as f:
            content = f.readlines()
    except Exception as ex:
        log.info("File: %s not found - Remote Plugin Module is detected", LINUX_FUNCTIONS_FILE)
        return None
    for line in content:
        line = line.strip()
        if line.startswith(parameter):
            dir = line.split("=")[1]
            return dir
    log.info(
        "Error when parsing %s file: file does not contain INSTALL_DIR",
        LINUX_FUNCTIONS_FILE,
    )
    return None
